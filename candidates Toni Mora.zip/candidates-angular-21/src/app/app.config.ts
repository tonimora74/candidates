import { ApplicationConfig, provideBrowserGlobalErrorListeners, isDevMode } from '@angular/core';
import { provideRouter } from '@angular/router';
import { provideHttpClient } from '@angular/common/http';
import { routes } from './app.routes';
import { TranslocoHttpLoader } from './transloco-loader';
import { provideTransloco } from '@jsverse/transloco';
import { environment } from '../environments/environment';


/**
 * Main application configuration object.
 *
 * - Enables global error listeners for browser errors.
 * - Provides routing and HTTP client services.
 * - Configures internationalization (i18n) with Transloco.
 * - Uses signals and disables zone.js for improved performance.
 */
export const appConfig: ApplicationConfig = {
  providers: [
  /**
   * Handles global browser errors.
   */
  provideBrowserGlobalErrorListeners(),
  /**
   * Sets up application routes.
   */
  provideRouter(routes),
  /**
   * Enables HttpClient for API and i18n requests.
   */
  provideHttpClient(),
  /**
   * Internationalization configuration with Transloco.
   */
  provideTransloco({
        config: { 
          availableLangs: environment.transloco.availableLangs,
          defaultLang: environment.transloco.defaultLang,
          reRenderOnLangChange: true,
          prodMode: !isDevMode(),
        },
        loader: TranslocoHttpLoader
      })
  ]
};
