import { Routes } from '@angular/router';
import { App } from './app';

/**
 * Application routes configuration.
 */
export const routes: Routes = [
	{ path: '', component: App },
	{ path: '**', redirectTo: '', pathMatch: 'full' }
];
