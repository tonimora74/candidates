import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { FormGroup, FormControl, Validators, ReactiveFormsModule } from '@angular/forms';

import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatDialog } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

import { TranslocoModule, TranslocoService } from '@jsverse/transloco';

import { ErrorMessageDialog } from './components/error-message-dialog/error-message-dialog';
import { TableCandidates } from './components/table-candidates/table-candidates';
import { CandidateResponse } from './components/table-candidates/interfaces/candidate-response.interface';
import { LanguageSelector } from './components/language-selector/language-selector';
import { excelFileValidator } from './validators/excel-file.validator';
import { environment } from '../environments/environment';


 @Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatCardModule,
    TranslocoModule,
    MatProgressSpinnerModule,
    TableCandidates,
    LanguageSelector
  ],
  templateUrl: './app.html',
  styleUrl: './app.scss'
})
/**
 * Main application component. Handles candidate form and state.
 *
 * - Manages form controls and candidate submission.
 * - Handles file input and validation.
 * - Integrates i18n and dialogs.
 */
export class App {
  
  loading = signal(false);
  candidate = signal<CandidateResponse | undefined>(undefined);
  /** Track the file name */
  excelFileName: string = '';

  submitEnabled = true;

  /** Sinstaxis more readable in the template */
  nameControl = new FormControl<string>('', [Validators.required, Validators.minLength(2)]);
  surnameControl = new FormControl<string>('', [Validators.required, Validators.minLength(2)]);
  excelControl = new FormControl<File | null>(null, [excelFileValidator]);
  
  /** Create the form group */
  form = new FormGroup({
    name: this.nameControl,
    surname: this.surnameControl,
    excel: this.excelControl,
  });

  /**
   * Creates the main app component.
   * @param http Angular HttpClient for API requests
   * @param dialog Material dialog service
   * @param transloco Transloco service for i18n
   */
  constructor(private http: HttpClient, private dialog: MatDialog, private transloco: TranslocoService) {}

  /**
   * Handles file input change event and validates the Excel file.
   * @param event File input change event
   * @returns void
   */
  onFileChange(event: Event): void {
    const input = event.target as HTMLInputElement;
    const excelControl = this.form.get('excel');
    if (input.files && input.files.length > 0) {
      const file = input.files[0];
      excelControl?.setValue(file);
      excelControl?.markAsTouched();
      excelControl?.updateValueAndValidity();
      this.excelFileName = file.name;
      // Invalid file, clean the input file and show error
      const errors = excelControl?.errors;
      if (errors && errors['invalidExtension']) {
        excelControl?.setValue(null);
        excelControl?.markAsTouched();
        excelControl?.updateValueAndValidity();
        input.value = '';
        this.excelFileName = '';
      }
    } else {
      // When the user delete the back file
      excelControl?.setValue(null);
      excelControl?.markAsTouched();
      excelControl?.updateValueAndValidity();
      this.excelFileName = '';
    }
  }

  // Send form data and Excel file to backend
  /**
   * Submits the candidate form and Excel file to the backend.
   * Shows spinner, sends POST request, handles response and errors.
   * @returns void
   */
  onSubmit(): void {
    // Show spinner
    this.loading.set(true);
    // Create FormData object
    const formData = new FormData();
    formData.append('name', this.nameControl.value ?? '');
    formData.append('surname', this.surnameControl.value ?? '');
    // Add Excel file only if it exists
    if (this.excelControl.value) {
      formData.append('excel', this.excelControl.value);
    }
    // Send POST request to backend
    this.http.post<CandidateResponse>(environment.apiUrlCandidates, formData).subscribe({
      next: (response) => {
        // Hide spinner
        this.loading.set(false);
        // Assign received data to the table
        this.candidate.set(response);
        // Reset the form
        this.form.reset();
        this.excelFileName = '';
        // Quitar validadores tras el reset
        this.nameControl.clearValidators();
        this.surnameControl.clearValidators();
        this.excelControl.clearValidators();
        Object.values(this.form.controls).forEach(control => {
          control.setErrors(null);
          control.markAsPristine();
          control.markAsUntouched();
          control.updateValueAndValidity();
        });
        this.submitEnabled = false;
      },
      error: (error) => {
        // Hide spinner and show error message
        this.loading.set(false);
        this.dialog.open(ErrorMessageDialog, {
          data: {
            title: this.transloco.translate('error-message-dialog.title', {}, 'es'),
            message:
              error?.error?.message ||
              error.message ||
              this.transloco.translate('error-message-dialog.default', {}, 'es')
          },
          width: '400px',
          disableClose: false
        });
      }
    });
  }

  /**
   * Restores validators for the name field and enables submit button.
   * @returns void
   */
  restoreNameValidators(): void {
    this.nameControl.setValidators([Validators.required, Validators.minLength(2)]);
    this.nameControl.updateValueAndValidity();
    this.submitEnabled = true;
  }

  /**
   * Restores validators for the surname field and enables submit button.
   * @returns void
   */
  restoreSurnameValidators() {
    this.surnameControl.setValidators([Validators.required, Validators.minLength(2)]);
    this.surnameControl.updateValueAndValidity();
    this.submitEnabled = true;
  }

  /**
   * Restores validators for the excel field and enables submit button.
   * @returns void
   */
  restoreExcelValidators() {
    this.excelControl.setValidators([excelFileValidator]);
    this.excelControl.updateValueAndValidity();
    this.submitEnabled = true;
  }
}
