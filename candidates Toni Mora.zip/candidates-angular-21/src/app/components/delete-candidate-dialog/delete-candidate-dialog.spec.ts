import { TestBed } from '@angular/core/testing';
import { DeleteCandidateDialog } from './delete-candidate-dialog';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { CandidateResponse } from '../table-candidates/interfaces/candidate-response.interface';
import { TRANSLOCO_TRANSPILER, DefaultTranspiler, TRANSLOCO_MISSING_HANDLER, DefaultMissingHandler, TRANSLOCO_INTERCEPTOR, DefaultInterceptor, TRANSLOCO_FALLBACK_STRATEGY, DefaultFallbackStrategy, TRANSLOCO_LOADER } from '@jsverse/transloco';

describe('DeleteCandidateDialog', () => {
  let component: DeleteCandidateDialog;
  let dialogRef: MatDialogRef<DeleteCandidateDialog>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [DeleteCandidateDialog],
      providers: [
        { provide: MAT_DIALOG_DATA, useValue: { name: 'Test', surname: 'User' } },
        { provide: MatDialogRef, useValue: { close: () => {} } },
        { provide: TRANSLOCO_TRANSPILER, useClass: DefaultTranspiler },
        { provide: TRANSLOCO_MISSING_HANDLER, useClass: DefaultMissingHandler },
        { provide: TRANSLOCO_INTERCEPTOR, useClass: DefaultInterceptor },
        { provide: TRANSLOCO_FALLBACK_STRATEGY, useClass: DefaultFallbackStrategy },
        { provide: TRANSLOCO_LOADER, useValue: { getTranslation: () => Promise.resolve({}) } }
      ]
    });
    const fixture = TestBed.createComponent(DeleteCandidateDialog);
    component = fixture.componentInstance;
    dialogRef = TestBed.inject(MatDialogRef);
  });

  it('should create the component', () => {
    expect(component).toBeTruthy();
  });

  it('should expose candidate data', () => {
    expect(component.data.name).toBe('Test');
    expect(component.data.surname).toBe('User');
  });

  it('should close dialog and clear data on closeDialog()', () => {
    let called = false;
    dialogRef.close = () => { called = true; };
    component.closeDialog();
    expect(called).toBe(true);
    expect(component.data).toEqual({} as CandidateResponse);
  });
});
