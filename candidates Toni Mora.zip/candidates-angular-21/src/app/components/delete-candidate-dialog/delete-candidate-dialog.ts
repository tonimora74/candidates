import { Component, Inject } from '@angular/core';

import { MatDialogModule, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';

import { TranslocoModule } from '@jsverse/transloco';

import { CandidateResponse } from '../table-candidates/interfaces/candidate-response.interface';

@Component({
  selector: 'delete-candidate-dialog',
  standalone: true,
  templateUrl: './delete-candidate-dialog.html',
  styleUrls: ['./delete-candidate-dialog.scss'],
  imports: [TranslocoModule, MatDialogModule, MatIconModule]
})
 /**
  * Dialog component for confirming candidate deletion.
  */
 export class DeleteCandidateDialog {
  /**
   * Candidate data passed to the dialog.
   */
  constructor(
    @Inject(MAT_DIALOG_DATA) public data: CandidateResponse,
    private dialogRef: MatDialogRef<DeleteCandidateDialog>
  ) {}

  // Closes the dialog when the close icon is clicked
  /**
   * Closes the dialog and clears candidate data.
   * @returns void
   */
  closeDialog(): void {
    this.dialogRef.close();
    // Clear data after closing to avoid showing stale info if reused
    this.data = {} as CandidateResponse;
  }
}
