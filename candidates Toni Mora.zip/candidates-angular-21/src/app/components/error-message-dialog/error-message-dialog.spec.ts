import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ErrorMessageDialog } from './error-message-dialog';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

describe('ErrorMessageDialog', () => {
  let component: ErrorMessageDialog;
  let fixture: ComponentFixture<ErrorMessageDialog>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ErrorMessageDialog],
      providers: [
        { provide: MAT_DIALOG_DATA, useValue: { title: 'Test tittle', message: 'Test message' } },
        { provide: MatDialogRef, useValue: { close: () => {} } }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(ErrorMessageDialog);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('comprobe params', () => {
    const testData = { title: 'Test tittle', message: 'Test message' };
    const dialogRefMock = { close: jasmine.createSpy('close') } as any;
    const component = new ErrorMessageDialog(testData, dialogRefMock);
    expect(component.title).toBe('Test tittle');
    expect(component.message).toBe('Test message');
  });

  it('invoque closeDialog', () => {
    const testData = { title: 'Test tittle', message: 'Test message' };
    const dialogRefMock = { close: jasmine.createSpy('close') } as any;
    const component = new ErrorMessageDialog(testData, dialogRefMock);
    component.closeDialog();
    expect(dialogRefMock.close).toHaveBeenCalled();
  });
});
