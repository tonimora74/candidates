import { Component, Inject } from '@angular/core';

import { MatDialogModule, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';

import { TranslocoModule } from '@jsverse/transloco';

/**
 * Interface for error message dialog data.
 */
export interface ErrorMessageData {
  /** Dialog title */
  title: string;
  /** Dialog message */
  message: string;
  /** Optional error code */
  code?: string;
}

@Component({
  selector: 'error-message-dialog',
  standalone: true,
  templateUrl: './error-message-dialog.html',
  styleUrls: ['./error-message-dialog.scss'],
  imports: [TranslocoModule, MatDialogModule, MatIconModule]
})
 /**
  * Dialog component for displaying error messages.
  */
 export class ErrorMessageDialog {
  title: string;
  message: string;

  /**
   * Creates the error message dialog component.
   * @param data Data for the error message dialog
   * @param dialogRef Reference to the dialog instance
   */
  constructor(
    @Inject(MAT_DIALOG_DATA) public data: ErrorMessageData,
    private dialogRef: MatDialogRef<ErrorMessageDialog>
  ) {
    this.title = data.title;
    this.message = data.message;
  }

  /**
   * Closes the dialog.
   * @returns void
   */
  closeDialog(): void {
    this.dialogRef.close();
  }
}
