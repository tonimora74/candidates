import { LanguageSelector } from './language-selector';
import { TranslocoService } from '@jsverse/transloco';

describe('LanguageSelector', () => {
  let translocoServiceMock: jasmine.SpyObj<TranslocoService>;
  let component: LanguageSelector;

  beforeEach(() => {
    translocoServiceMock = jasmine.createSpyObj('TranslocoService', ['getAvailableLangs', 'getActiveLang', 'setActiveLang']);
    translocoServiceMock.getAvailableLangs.and.returnValue(['en', 'es']);
    translocoServiceMock.getActiveLang.and.returnValue('en');
    component = new LanguageSelector(translocoServiceMock);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize langs and activeLang', () => {
    expect(component.langs).toEqual(['en', 'es']);
    expect(component.activeLang).toBe('en');
  });

  it('should change language', () => {
    component.changeLang('es');
    expect(translocoServiceMock.setActiveLang).toHaveBeenCalledWith('es');
    expect(component.activeLang).toBe('es');
  });
});
