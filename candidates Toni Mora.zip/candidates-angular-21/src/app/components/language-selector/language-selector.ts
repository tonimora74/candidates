import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { MatSelectModule } from '@angular/material/select';

import { TranslocoModule, TranslocoService } from '@jsverse/transloco';

@Component({
  selector: 'language-selector',
  standalone: true,
  imports: [CommonModule, MatSelectModule, TranslocoModule, FormsModule],
  templateUrl: './language-selector.html',
})
 /**
  * Language selector component for switching application language.
  */
 export class LanguageSelector implements OnInit {
  
  /** List of available languages */
  langs: string[] = [];
  /** Currently active language */
  activeLang: string = '';

  constructor(private translocoService: TranslocoService) {}

  ngOnInit() {
    this.langs = this.translocoService.getAvailableLangs() as string[];
    this.activeLang = this.translocoService.getActiveLang();
  }

  /**
   * Changes the active language.
   * @param lang Language code to activate
   * @returns void
   */
  changeLang(lang: string): void {
    this.translocoService.setActiveLang(lang);
    this.activeLang = lang;
  }
}
