/**
 * Interface representing a candidate response from the backend.
 */
export interface CandidateResponse {
  /** Candidate's name */
  name: string;
  /** Candidate's surname */
  surname: string;
  /** Candidate's seniority level */
  seniority: string;
  /** Candidate's years of experience */
  years: number;
  /** Candidate's availability status */
  availability: boolean;
}
