import { TestBed } from '@angular/core/testing';
import { TableCandidates } from './table-candidates';
import { MatDialog } from '@angular/material/dialog';
import { CandidateResponse } from './interfaces/candidate-response.interface';

describe('TableCandidates', () => {
  let component: TableCandidates;
  let dialog: MatDialog;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [TableCandidates],
      providers: [
        { provide: MatDialog, useValue: { open: () => {} } }
      ]
    });
    const fixture = TestBed.createComponent(TableCandidates);
    component = fixture.componentInstance;
    dialog = TestBed.inject(MatDialog);
  });

  it('should create the component', () => {
    expect(component).toBeTruthy();
  });

  it('should add a candidate when input is set', () => {
    // Mocks
    const candidate: CandidateResponse = {
      name: 'Test', surname: 'User', seniority: 'Senior', years: 5, availability: true
    } as any;
    // Act
    component.candidate = candidate;

    expect(component.candidates()).toContain(candidate);
  });    

  it('should remove candidate and open dialog', () => {
    // Mocks
    const candidate: CandidateResponse = {
      name: 'Test', surname: 'User', seniority: 'Senior', years: 5, availability: true
    } as any;
    component.candidates.set([candidate]);
    let called = false;
    dialog.open = () => { called = true; return { close: () => {} } as any; };
    // Act
    component.removeCandidate(0);
    
    expect(component.candidates()).not.toContain(candidate);
    expect(called).toBe(true);
  });
});
