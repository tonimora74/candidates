import { Component, Input, signal } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MatCardModule } from '@angular/material/card';
import { MatDialog } from '@angular/material/dialog';
import { MatIconModule } from '@angular/material/icon';
import { MatTableModule } from '@angular/material/table';

import { TranslocoModule } from '@jsverse/transloco';

import { DeleteCandidateDialog } from '../delete-candidate-dialog/delete-candidate-dialog';
import { CandidateResponse } from './interfaces/candidate-response.interface';

@Component({
  selector: 'table-candidates',
  standalone: true,
  imports: [CommonModule, MatTableModule, MatCardModule, TranslocoModule, MatIconModule],
  templateUrl: './table-candidates.html',
  styleUrls: ['./table-candidates.scss']
})
 /**
  * Table component to display and manage added candidates.
  */
 export class TableCandidates {

  /**
   * Signal holding the list of candidates displayed in the table.
   */
  candidates = signal<CandidateResponse[]>([]);
  
  /**
   * Creates the table candidates component.
   * @param dialog Material dialog service
   */
  constructor(private dialog: MatDialog) {}

  /**
   * Input property to add a candidate to the table.
   * @param value Candidate to add
   */
  @Input()
  set candidate(value: CandidateResponse | undefined) {
    if (value) {
      this.candidates.set([...this.candidates(), value]);
    }
  }

  /**
   * Columns displayed in the table.
   */
  displayedColumns: string[] = ['name', 'surname', 'seniority', 'years', 'availability', 'actions'];

  /**
   * Removes a candidate from the table.
   * @param index Index of the candidate to remove
   * @returns void
   */
  removeCandidate(index: number): void {
    // Create a copy of the candidates array
    const arr = [...this.candidates()];
    // Get the candidate to be deleted by index
    const deleted = arr[index];
    // Remove the candidate from the array
    arr.splice(index, 1);
    // Update the candidates signal with the new array
    this.candidates.set(arr);
    // Open the DeleteCandidateDialog modal, passing the deleted candidate's data
    this.dialog.open(DeleteCandidateDialog, {
      data: deleted,
      width: '350px',
      disableClose: true
    });
  }
}
