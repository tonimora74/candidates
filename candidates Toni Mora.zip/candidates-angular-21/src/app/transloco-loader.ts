import { Observable } from 'rxjs';
import { inject, Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";

import { Translation, TranslocoLoader } from "@jsverse/transloco";

/**
 * Injectable loader for Transloco language translations.
 */
@Injectable({ providedIn: 'root' })
 /**
  * Custom loader for Transloco to fetch language translations via HTTP.
  */
 export class TranslocoHttpLoader implements TranslocoLoader {
    /**
     * Angular HttpClient instance for HTTP requests.
     */
    private http = inject(HttpClient);

    /**
     * Fetches translation file for the given language.
     * @param lang Language code (e.g. 'en', 'es')
     * @returns Observable with translation data
     */
    getTranslation(lang: string): Observable<Translation> {
        return this.http.get<Translation>(`/i18n/${lang}.json`);
    }
}
