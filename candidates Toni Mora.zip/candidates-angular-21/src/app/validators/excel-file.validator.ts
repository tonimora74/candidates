import { AbstractControl, ValidationErrors } from '@angular/forms';

/**
 * Validator for Excel file input in candidate form.
 * @param control Form control to validate
 * @returns Validation errors or null
 */
export function excelFileValidator(control: AbstractControl): ValidationErrors | null {
  const file = control.value as File | null;
  if (!file) {
    return { required: true };
  }
  const validExtensions = ['.xlsx', '.xls'];
  const fileName = file.name?.toLowerCase() || '';
  const isValidExtension = validExtensions.some(ext => fileName.endsWith(ext));
  if (!isValidExtension) {
    return { invalidExtension: true };
  }
  return null;
}
