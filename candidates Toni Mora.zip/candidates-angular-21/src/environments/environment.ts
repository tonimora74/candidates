/**
 * Application environment configuration (development).
 */
export const environment = {
  production: false,
  apiUrlCandidates: 'http://localhost:3000/candidates',
  transloco: {
    availableLangs: ['en', 'es'],
    defaultLang: 'es'
  }
};
