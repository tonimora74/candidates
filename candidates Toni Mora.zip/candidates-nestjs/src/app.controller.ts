// nestjs
import { Controller, Get } from '@nestjs/common';
import { ApiResponse } from '@nestjs/swagger';

// application files
import { AppService } from './app.service';

@Controller()
export class AppController {
  constructor(private readonly appService: AppService) {}

  @ApiResponse({
    status: 200,
    description: 'Returns a hello message',
    schema: {
      type: 'object',
      properties: {
        message: { type: 'string', example: 'Hello World!' },
      },
    },
  })
  @Get()
  getHello(): { message: string } {
    return { message: this.appService.getHello() };
  }

  @ApiResponse({
    status: 200,
    description: 'Health check endpoint',
    schema: {
      type: 'object',
      properties: {
        status: { type: 'string', example: 'ok' },
        timestamp: {
          type: 'string',
          format: 'date-time',
          example: '2025-11-26T12:00:00.000Z',
        },
      },
    },
  })
  @Get('health')
  healthCheck() {
    return { status: 'ok', timestamp: new Date().toISOString() };
  }
}
