// nestjs
import { Test, TestingModule } from '@nestjs/testing';

// application files
import { AppModule } from './app.module';
import { AppController } from './app.controller';
import { AppService } from './app.service';

describe('AppModule', () => {
  let module: TestingModule;

  beforeAll(async () => {
    module = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();
  });

  it('should define AppController', () => {
    const controller = module.get<AppController>(AppController);
    expect(controller).toBeDefined();
  });

  it('should define AppService', () => {
    const service = module.get<AppService>(AppService);
    expect(service).toBeDefined();
  });
});
