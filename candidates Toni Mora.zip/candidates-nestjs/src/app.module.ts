// nestjs
import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';

// application files
import { CandidatesModule } from './candidates/candidates.module';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { getEnvFilePath } from './environment/config-env';

@Module({
  imports: [
    // eslint-disable-next-line @typescript-eslint/no-unsafe-call, @typescript-eslint/no-unsafe-member-access
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: getEnvFilePath(process.env.NODE_ENV),
    }),
    CandidatesModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
