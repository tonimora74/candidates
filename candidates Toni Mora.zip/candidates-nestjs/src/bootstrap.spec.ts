// nestjs
import { NestFactory } from '@nestjs/core';

// application files
import { bootstrap } from './bootstrap';
import { AppModule } from './app.module';
import { NotFoundFilter } from './common/filters/not-found.filter';
// Swagger mock
import { SwaggerModule } from '@nestjs/swagger';
import { createAppMock } from './test-utils/app-mock';

describe('Main bootstrap', () => {
  let appInstanceSpy: jest.SpyInstance;
  let useGlobalFiltersSpy: jest.SpyInstance;
  let enableCorsSpy: jest.SpyInstance;
  let listenSpy: jest.SpyInstance;
  let swaggerSpy: jest.SpyInstance;

  beforeEach(() => {
    appInstanceSpy = jest.spyOn(NestFactory, 'create').mockResolvedValue({
      useGlobalFilters: jest.fn(),
      enableCors: jest.fn(),
      listen: jest.fn(),
    } as unknown as import('@nestjs/common').INestApplication);
    useGlobalFiltersSpy = jest.fn();
    enableCorsSpy = jest.fn();
    listenSpy = jest.fn();
    swaggerSpy = jest.spyOn(SwaggerModule, 'createDocument').mockReturnValue({
      openapi: '3.0.0',
      info: { title: '', version: '' },
      paths: {},
    });
  });

  afterEach(() => {
    jest.restoreAllMocks();
    if (swaggerSpy) swaggerSpy.mockRestore();
  });

  it('should bootstrap the app and register NotFoundFilter and CORS', async () => {
    process.env.API_URL_CANDIDATES = 'http://localhost';
    process.env.PORT = '3100';
    const appMock = createAppMock({
      useGlobalFiltersSpy,
      enableCorsSpy,
      listenSpy,
    });
    appInstanceSpy.mockResolvedValue(appMock as any);

    // Call bootstrap directly
    await bootstrap();

    expect(appInstanceSpy).toHaveBeenCalledWith(AppModule);
    expect(useGlobalFiltersSpy).toHaveBeenCalledWith(
      expect.any(NotFoundFilter),
    );
    expect(enableCorsSpy).toHaveBeenCalledWith({
      origin: 'http://localhost',
      methods: 'POST',
      credentials: true,
    });
    expect(listenSpy).toHaveBeenCalledWith('3100');
  });

  it('should use default port 3000 if process.env.PORT is undefined', async () => {
    process.env.API_URL_CANDIDATES = 'http://localhost';
    delete process.env.PORT;
    const appMock = createAppMock({
      useGlobalFiltersSpy,
      enableCorsSpy,
      listenSpy,
    });
    appInstanceSpy.mockResolvedValue(appMock as any);

    await bootstrap();

    expect(listenSpy).toHaveBeenCalledWith(3000);
  });
});
