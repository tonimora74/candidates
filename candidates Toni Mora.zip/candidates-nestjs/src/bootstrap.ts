// nestjs
import { NestFactory } from '@nestjs/core';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';

// application files
import { AppModule } from './app.module';
import { NotFoundFilter } from './common/filters/not-found.filter';
import { IpFilterMiddleware } from './middleware/ip-filter.middleware';

export async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  // Apply IP filter before anything else
  app.use(new IpFilterMiddleware().use);
  // For "not found" routes
  app.useGlobalFilters(new NotFoundFilter());
  // CORS configuration
  app.enableCors({
    origin: process.env.API_URL_CANDIDATES,
    methods: 'POST',
    credentials: true,
  });

  // Swagger documentation configuration
  const config = new DocumentBuilder()
    .setTitle('API Documentation')
    .setDescription('NestJS API Swagger')
    .setVersion('1.0')
    .build();
  const document = SwaggerModule.createDocument(app, config);
  SwaggerModule.setup('api/docs', app, document);
  await app.listen(process.env.PORT ?? 3000);
}
