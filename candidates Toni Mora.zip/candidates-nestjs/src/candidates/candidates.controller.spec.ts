/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
// nestjs
import { Test, TestingModule } from '@nestjs/testing';

// application files
import { CandidatesController } from './candidates.controller';
import { CandidatesExcelService } from './services/candidates-excel.service';
import { CandidatesRequestWhitoutExcelDto } from './dto/candidates/candidates-request.dto';

describe('CandidatesController', () => {
  let candidatesController: CandidatesController;
  let candidatesExcelService: CandidatesExcelService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [CandidatesController],
      providers: [CandidatesExcelService],
    }).compile();

    candidatesController =
      module.get<CandidatesController>(CandidatesController);
    candidatesExcelService = module.get<CandidatesExcelService>(
      CandidatesExcelService,
    );
  });

  it('should be defined', () => {
    expect.assertions(1);

    expect(candidatesController).toBeDefined();
  });

  it('should process candidate and return response', () => {
    expect.assertions(1);

    const body: CandidatesRequestWhitoutExcelDto = { name: 'John', surname: 'Doe' };
    const file: any = { buffer: Buffer.alloc(0) };
    jest.spyOn(candidatesExcelService, 'processCandidate').mockReturnValue({
      seniority: 'junior',
      years: 2,
      availability: true,
    });
    const result = candidatesController.candidates(body, file);
    expect(result).toEqual({
      name: 'John',
      surname: 'Doe',
      seniority: 'junior',
      years: 2,
      availability: true,
    });
  });

  it('should call res.download with correct file path and filename', () => {
    expect.assertions(2);

    // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
    const res = { download: jest.fn() } as any;

    candidatesController.downloadExcel(res);

    const callArgs = res.download.mock.calls[0];
    expect(callArgs[0]).toMatch(/files[\\/]+candidates\.xlsx$/);
    expect(callArgs[1]).toBe('candidates_template.xlsx');
  });
});
