// Node imports
import { join } from 'path';

// External imports
import type { Express, Response } from 'express';

// NestJS imports
import {
  Controller,
  Post,
  Body,
  UploadedFile,
  UseInterceptors,
  UsePipes,
  ValidationPipe,
  Get,
  Res,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { ApiBody, ApiConsumes, ApiResponse, ApiTags } from '@nestjs/swagger';

// Application imports
import { CandidatesRequestWhitoutExcelDto } from './dto/candidates/candidates-request.dto';
import { CandidatesExcelService } from './services/candidates-excel.service';
import { CandidatesResponseDto } from './dto/candidates/candidate-response.dto';
import { ExcelValidationPipe } from './pipes/excel-validation.pipe';
import { CandidateRequestDto } from './dto/candidates-swagger/candidate-request-swagger.dto';

// Documentation tag for Swagger UI
@ApiTags('candidates')
// Controller definition
@Controller('candidates')
export class CandidatesController {
  constructor(
    private readonly candidatesExcelService: CandidatesExcelService,
  ) {}

  // Documentation for Swagger UI
  @ApiConsumes('multipart/form-data')
  @ApiBody({ type: CandidateRequestDto })
  @ApiResponse({
    status: 201,
    description: 'Candidate created',
    type: CandidatesResponseDto,
  })
  // Endpoint to create candidates
  @Post()
  @UseInterceptors(FileInterceptor('excel'))
  @UsePipes(new ValidationPipe({ whitelist: true }))
  candidates(
    // Request body without the excel file
    @Body() body: CandidatesRequestWhitoutExcelDto,
    // Excel file upload independent parameter for NestJS
    @UploadedFile(new ExcelValidationPipe()) file: Express.Multer.File,
  ): CandidatesResponseDto {
    // Get data from excel file
    const excelData = this.candidatesExcelService.processCandidate(file.buffer);
    // Return combined data
    return {
      name: body.name,
      surname: body.surname,
      seniority: excelData.seniority,
      years: excelData.years,
      availability: excelData.availability,
    };
  }

  @ApiResponse({
    status: 200,
    description: 'Download example Excel file',
    content: {
      'application/octet-stream': {
        schema: {
          type: 'string',
          format: 'binary',
        },
        example: 'Excel file download',
      },
    },
  })
  @Get('example-excel')
  downloadExcel(@Res() res: Response) {
    const filePath = join(__dirname, '..', 'files', 'candidates.xlsx');
    res.download(filePath, 'candidates_template.xlsx');
  }
}
