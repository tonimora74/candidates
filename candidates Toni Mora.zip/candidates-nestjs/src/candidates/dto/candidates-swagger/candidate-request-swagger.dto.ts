import { ApiProperty } from '@nestjs/swagger';

export class CandidateRequestDto {
  @ApiProperty({ description: 'Candidate name' })
  name: string;

  @ApiProperty({ description: 'Candidate surname' })
  surname: string;

  @ApiProperty({
    type: 'string',
    format: 'binary',
    description: 'Excel file (.xlsx)',
  })
  excel: string;
}
