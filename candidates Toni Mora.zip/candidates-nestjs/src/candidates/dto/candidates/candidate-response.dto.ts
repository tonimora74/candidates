import { ApiProperty } from '@nestjs/swagger';

export class CandidatesResponseDto {
  @ApiProperty({ description: 'Candidate name' })
  name: string;

  @ApiProperty({ description: 'Candidate surname' })
  surname: string;

  @ApiProperty({ description: 'Seniority level' })
  seniority: string;

  @ApiProperty({ description: 'Years of experience' })
  years: number;

  @ApiProperty({ description: 'Availability' })
  availability: boolean;
}
