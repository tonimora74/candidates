// Swagger imports
import { ApiProperty } from '@nestjs/swagger';

// third-party library
import { IsString, IsNotEmpty } from 'class-validator';

export class CandidatesRequestWhitoutExcelDto {
  @ApiProperty({ description: 'Candidate name' })
  @IsString()
  @IsNotEmpty()
  name: string;

  @ApiProperty({ description: 'Candidate surname' })
  @IsString()
  @IsNotEmpty()
  surname: string;
}
