export type Seniority = 'junior' | 'senior';

export interface CandidateRequest {
  name: string;
  surname: string;
  excel: Buffer;
}
