// application files
import { Seniority } from './candidate-request.interface';

export interface CandidatesExcelServiceResponse {
  seniority: Seniority;
  years: number;
  availability: boolean;
}
