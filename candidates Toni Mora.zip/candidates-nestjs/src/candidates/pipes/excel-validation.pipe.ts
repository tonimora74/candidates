// nestjs
import { PipeTransform, Injectable, BadRequestException } from '@nestjs/common';

// third-party library
import * as XLSX from 'xlsx';

@Injectable()
export class ExcelValidationPipe implements PipeTransform {
  transform(file: Express.Multer.File) {
    // Validation required
    if (!file) {
      throw new BadRequestException(
        'Excel file is required. You can download a valid example Excel at /candidates/example-excel',
      );
    }
    // Validation MIME type
    if (
      file.mimetype !==
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    ) {
      throw new BadRequestException(
        'File must be an .xlsx Excel file. You can download a valid example Excel at /candidates/example-excel',
      );
    }
    // Validation not empty
    if (!file.buffer || file.buffer.length === 0) {
      throw new BadRequestException(
        'Excel file is empty. You can download a valid example Excel at /candidates/example-excel',
      );
    }
    // Validation file size
    if (file.size > 200 * 1024) {
      throw new BadRequestException(
        'Excel file must not exceed 200KB. You can download a valid example Excel at /candidates/example-excel',
      );
    }
    // Validations headers and values
    const workbook = XLSX.read(file.buffer, { type: 'buffer' });
    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];
    const rows = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
    if (!rows || rows.length !== 2) {
      throw new BadRequestException(
        'Excel file must have exactly one header row and one row of values. You can download a valid example Excel at /candidates/example-excel',
      );
    }
    const [rawHeaders, rawValues] = rows;
    const headers = rawHeaders as string[];
    const values = rawValues as (string | number)[];
    if (!headers || headers.length !== 3) {
      throw new BadRequestException(
        'Excel file must have exactly 3 headers. You can download a valid example Excel at /candidates/example-excel',
      );
    }
    if (!values || values.length !== 3) {
      throw new BadRequestException(
        'Excel file must have exactly 3 values. You can download a valid example Excel at /candidates/example-excel',
      );
    }
    for (let i = 0; i < values.length; i++) {
      if (
        values[i] === undefined ||
        values[i] === null ||
        String(values[i]).trim() === ''
      ) {
        throw new BadRequestException(
          `Excel file value at position ${i + 1} is empty or invalid. You can download a valid example Excel at /candidates/example-excel`,
        );
      }
    }
    return file;
  }
}
