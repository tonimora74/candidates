// application files
import { getEnvFilePath } from './config-env';

describe('getEnvFilePath', () => {
  it('should return ./src/environment/.env.production when nodeEnv is production', () => {
    expect(getEnvFilePath('production')).toBe(
      './src/environment/.env.production',
    );
  });

  it('should return ./src/environment/.env.development when nodeEnv is not production', () => {
    expect(getEnvFilePath('development')).toBe(
      './src/environment/.env.development',
    );
    expect(getEnvFilePath(undefined)).toBe(
      './src/environment/.env.development',
    );
    expect(getEnvFilePath('test')).toBe('./src/environment/.env.development');
  });
});
