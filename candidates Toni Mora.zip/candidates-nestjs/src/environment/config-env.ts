// application files
export function getEnvFilePath(nodeEnv?: string): string {
  return nodeEnv === 'production'
    ? './src/environment/.env.production'
    : './src/environment/.env.development';
}
