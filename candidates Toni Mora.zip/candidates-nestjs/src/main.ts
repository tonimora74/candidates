// application files
import { bootstrap } from './bootstrap';

void bootstrap();
