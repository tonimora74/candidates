import { IpFilterMiddleware } from './ip-filter.middleware';
import { Request, Response } from 'express';

describe('IpFilterMiddleware', () => {
  let middleware: IpFilterMiddleware;
  let next: jest.Mock;

  beforeEach(() => {
    middleware = new IpFilterMiddleware();
    next = jest.fn();
    process.env.ALLOWED_IPS = '127.0.0.1,::1';
  });

  it('should allow request from allowed IP', () => {
    const req = { ip: '127.0.0.1' } as Request;
    const res = {} as Response;
    expect(() => middleware.use(req, res, next)).not.toThrow();
    expect(next).toHaveBeenCalled();
  });

  it('should deny request from disallowed IP', () => {
    const req = { ip: '8.8.8.8' } as Request;
    const res = {} as Response;
    expect(() => middleware.use(req, res, next)).toThrow(
      'Access denied from this IP',
    );
    expect(next).not.toHaveBeenCalled();
  });

  it('should allow request from allowed IP in x-forwarded-for', () => {
    const req = {
      ip: '',
      headers: { 'x-forwarded-for': '::1' },
    } as unknown as Request;
    const res = {} as Response;
    expect(() => middleware.use(req, res, next)).not.toThrow();
    expect(next).toHaveBeenCalled();
  });

  it('should handle empty IP and deny access', () => {
    const req = { ip: '', headers: {} } as Request;
    const res = {} as Response;
    expect(() => middleware.use(req, res, next)).toThrow(
      'Access denied from this IP',
    );
    expect(next).not.toHaveBeenCalled();
  });

  it('should allow request from allowed IP in req.socket.remoteAddress', () => {
    const req = {
      ip: '',
      headers: {},
      socket: { remoteAddress: '127.0.0.1' },
    } as unknown as Request;
    const res = {} as Response;
    expect(() => middleware.use(req, res, next)).not.toThrow();
    expect(next).toHaveBeenCalled();
  });
});
