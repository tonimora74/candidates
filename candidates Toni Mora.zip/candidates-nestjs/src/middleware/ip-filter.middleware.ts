// Node imports
import { Request, Response, NextFunction } from 'express';

// NestJS imports
import { Injectable, NestMiddleware, ForbiddenException } from '@nestjs/common';

@Injectable()
export class IpFilterMiddleware implements NestMiddleware {
  use = (req: Request, res: Response, next: NextFunction) => {
    // Get allowed IPs from environment variable at runtime
    const ALLOWED_IPS = (process.env.ALLOWED_IPS || '')
      .split(',')
      .map((ip) => ip.trim());

    // Get client IP using recommended properties. Avoid deprecated 'connection.remoteAddress'.
    // Covers direct, proxy (x-forwarded-for), and socket scenarios.
    const ip =
      req.ip ||
      (Array.isArray(req.headers['x-forwarded-for'])
        ? req.headers['x-forwarded-for'][0]
        : req.headers['x-forwarded-for']) ||
      req.socket?.remoteAddress ||
      '';
    if (!ALLOWED_IPS.includes(ip)) {
      throw new ForbiddenException('Access denied from this IP');
    }
    next();
  };
}
