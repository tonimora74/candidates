// Mocks for INestApplication in bootstrap tests

export function createAppMock({
  useGlobalFiltersSpy,
  enableCorsSpy,
  listenSpy,
}: {
  useGlobalFiltersSpy: jest.MockInstance<any, any>;
  enableCorsSpy: jest.MockInstance<any, any>;
  listenSpy: jest.MockInstance<any, any>;
}) {
  return {
    // Methods used by bootstrap
    use: jest.fn(),
    useGlobalFilters: useGlobalFiltersSpy,
    enableCors: enableCorsSpy,
    listen: listenSpy,
    // Required by SwaggerModule.setup
    useStaticAssets: jest.fn(),
    // Required by SwaggerModule.createDocument and setup
    getHttpAdapter: jest.fn().mockReturnValue({
      getType: () => 'express', // Swagger uses getType to detect the server type
      get: jest.fn(), // Swagger expects this method in the Express adapter
    }),
    // Required by SwaggerModule.createDocument
    getModules: jest.fn().mockReturnValue({}),
  };
}
