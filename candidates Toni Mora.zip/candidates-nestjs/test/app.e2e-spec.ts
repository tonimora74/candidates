/* eslint-disable @typescript-eslint/no-unsafe-member-access */
import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication } from '@nestjs/common';
import request from 'supertest';
import { App } from 'supertest/types';
import { AppModule } from './../src/app.module';
import { NotFoundFilter } from './../src/common/filters/not-found.filter';

describe('AppController (e2e)', () => {
  let app: INestApplication<App>;

  beforeEach(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    app = moduleFixture.createNestApplication();
    app.useGlobalFilters(new NotFoundFilter());
    await app.init();
  });

  it('/ (GET)', async () => {
    expect.assertions(2);

    const response = await request(app.getHttpServer()).get('/');

    expect(response.text).toBe(
      'Hello candidates application!  Welcome aboard!',
    );
    expect(response.status).toBe(200);
  });

  it('/health (GET)', async () => {
    expect.assertions(2);

    const response = await request(app.getHttpServer()).get('/health');

    expect(response.body).toHaveProperty('status', 'ok');
    expect(response.body).toHaveProperty('timestamp');
  });

  it('/health (POST) error', async () => {
    expect.assertions(5);

    const response = await request(app.getHttpServer()).post('/health');

    expect(response.body).toHaveProperty('statusCode', 404);
    expect(response.body).toHaveProperty('message', 'Route not found');
    expect(response.body).toHaveProperty('error', 'Not Found');
    expect(response.body).toHaveProperty('timestamp');
    expect(typeof response.body.timestamp).toBe('string');
  });

  it('should return custom 404 error for undefined route', async () => {
    expect.assertions(5);

    const response = await request(app.getHttpServer()).get(
      '/non-existent-route',
    );

    expect(response.body).toHaveProperty('statusCode', 404);
    expect(response.body).toHaveProperty('message', 'Route not found');
    expect(response.body).toHaveProperty('error', 'Not Found');
    expect(response.body).toHaveProperty('timestamp');
    expect(typeof response.body.timestamp).toBe('string');
  });
});
