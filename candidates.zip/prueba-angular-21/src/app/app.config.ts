import { ApplicationConfig, provideBrowserGlobalErrorListeners, isDevMode } from '@angular/core';
import { provideRouter } from '@angular/router';
import { provideHttpClient } from '@angular/common/http';
import { routes } from './app.routes';
import { TranslocoHttpLoader } from './transloco-loader';
import { provideTransloco } from '@jsverse/transloco';
import { environment } from '../environments/environment';


export const appConfig: ApplicationConfig = {
  providers: [
    provideBrowserGlobalErrorListeners(),
    // Provide routing if your app uses it
    provideRouter(routes),
    // Enables HttpClient service globally for the app (required for ngx-translate and HTTP requests)
    provideHttpClient(),
    // I18N internationalization configuration
    provideTransloco({
        config: { 
          availableLangs: environment.transloco.availableLangs,
          defaultLang: environment.transloco.defaultLang,
          reRenderOnLangChange: true,
          prodMode: !isDevMode(),
        },
        loader: TranslocoHttpLoader
      })
  ]
};
