import { TestBed } from '@angular/core/testing';
import { App } from './app';
import { TRANSLOCO_TRANSPILER, DefaultTranspiler, TRANSLOCO_MISSING_HANDLER, DefaultMissingHandler, TRANSLOCO_INTERCEPTOR, DefaultInterceptor, TRANSLOCO_FALLBACK_STRATEGY, DefaultFallbackStrategy, TRANSLOCO_LOADER } from '@jsverse/transloco';
import { TranslocoService } from '@jsverse/transloco';
import { HttpClient } from '@angular/common/http';
import { MatDialog } from '@angular/material/dialog';

class TranslocoMockLoader {
  getTranslation(lang: string) {
    return Promise.resolve({
      'app-root.form.title': 'Formulario para insertar candidatos'
    });
  }
}

describe('App', () => {
  let transloco: TranslocoService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [App],
      providers: [
        { provide: TRANSLOCO_TRANSPILER, useClass: DefaultTranspiler },
        { provide: TRANSLOCO_MISSING_HANDLER, useClass: DefaultMissingHandler },
        { provide: TRANSLOCO_INTERCEPTOR, useClass: DefaultInterceptor },
        { provide: TRANSLOCO_FALLBACK_STRATEGY, useClass: DefaultFallbackStrategy },
        { provide: TRANSLOCO_LOADER, useClass: TranslocoMockLoader }
      ]
    }).compileComponents();
    transloco = TestBed.inject(TranslocoService);
    transloco.setActiveLang('es');

    (transloco.translate as any) = (key: string) => {
      if (key === 'app-root.form.title') return 'Formulario para insertar candidatos';
      return key;
    };
  });

  it('should create the app', () => {
    const fixture = TestBed.createComponent(App);
    const app = fixture.componentInstance;
    expect(app).toBeTruthy();
  });

  it('should render title', async () => {
    const fixture = TestBed.createComponent(App);
    await fixture.whenStable();
    const compiled = fixture.nativeElement as HTMLElement;
    expect(compiled.querySelector('mat-card-title')?.textContent).toContain('Formulario para insertar candidatos');
  });

  describe('onFileChange', () => {
    let fixture: any;
    let component: App;

    beforeEach(() => {
      fixture = TestBed.createComponent(App);
      component = fixture.componentInstance;
    });

    it('Input file correct whitout errors', () => {
      expect.assertions(2);
      // Mocks
      const file = new File([''], 'test.xlsx', {
        type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
      });
      const event = { target: { files: [file] } } as any;
      component.excelControl.setErrors(null);
      // Act
      component.onFileChange(event);
      
      expect(component.excelControl.value).toBe(file);
      expect(component.excelFileName).toBe('test.xlsx');
    });

    it('File with invalid extension', () => {
      expect.assertions(3);
      // Mocks
      const file = new File([''], 'test.txt', { type: 'text/plain' });
      const event = { target: { files: [file], value: 'test.txt' } } as any;
      component.excelControl.setErrors({ invalidExtension: true });
      // Act
      component.onFileChange(event);

      expect(component.excelControl.value).toBeNull();
      expect(component.excelFileName).toBe('');
      expect(event.target.value).toBe('');
    });

    it('the user delete the back file', () => {
      expect.assertions(2);
      // Mocks
      const event = { target: { files: [] } } as any;
      component.excelControl.setValue(null);
      component.excelFileName = 'test.xlsx';
      // Act
      component.onFileChange(event);
      
      expect(component.excelControl.value).toBeNull();
      expect(component.excelFileName).toBe('');
    });
  });

  describe('onSubmit', () => {
    let fixture: any;
    let component: App;
    let http: HttpClient;
    let dialog: MatDialog;

    beforeEach(() => {
      fixture = TestBed.createComponent(App);
      component = fixture.componentInstance;
      http = TestBed.inject(HttpClient);
      dialog = TestBed.inject(MatDialog);
    });

    it('call url candidates and return ok data', () => {
      expect.assertions(2);
      // Mocks
      const mockResponse = { id: 1, name: 'Test', surname: 'User' };
      // Mock HttpClient.post
      (http.post as any) = () => ({
        subscribe: ({ next }: any) => next(mockResponse)
      });
      component.nameControl.setValue('Test');
      component.surnameControl.setValue('User');
      component.excelControl.setValue(null);
      // Act
      component.onSubmit();

      expect(component.loading()).toBe(false);
      expect(component.candidate()).toEqual(mockResponse);
    });

    it('call url candidates return error', () => {
      expect.assertions(3);
      // Mocks
      const mockError = { error: { message: 'Error de backend' } };
      // Mock HttpClient.post
      (http.post as any) = () => ({
        subscribe: ({ error }: any) => error(mockError)
      });
      // Spy manual para dialog.open
      let dialogOpenCalled = false;
      let dialogOpenArgs: any = null;
      (dialog.open as any) = (componentArg: any, configArg: any) => {
        dialogOpenCalled = true;
        dialogOpenArgs = configArg;
        return {};
      };
      component.nameControl.setValue('Test');
      component.surnameControl.setValue('User');
      component.excelControl.setValue(null);
      // Act
      component.onSubmit();
      
      expect(component.loading()).toBe(false);
      expect(dialogOpenCalled).toBe(true);
      expect(dialogOpenArgs.data.message).toBe('Error de backend');
    });

    it('should activate and deactivate spinner (loading) during submit', () => {
      expect.assertions(2);
      // Mocks
      const loadingStates: boolean[] = [];
      (component.loading.set as any) = (value: boolean) => {
        loadingStates.push(value);
      };
      (http.post as any) = () => ({
        subscribe: ({ next }: any) => next({ id: 1 })
      });
      component.nameControl.setValue('Test');
      component.surnameControl.setValue('User');
      component.excelControl.setValue(null);
      // Act
      component.onSubmit();

      expect(loadingStates[0]).toBe(true);
      expect(loadingStates[loadingStates.length - 1]).toBe(false);
    });

    it('should show default error message if backend error has no message', () => {
      // Simula error sin ninguna propiedad relevante
      const mockError = {};
      (http.post as any) = () => ({
        subscribe: ({ error }: any) => error(mockError)
      });
      // Mock dialog.open usando el provider
      let dialogOpenCalled = false;
      let dialogOpenArgs: any = null;
      (dialog.open as any) = (componentArg: any, configArg: any) => {
        dialogOpenCalled = true;
        dialogOpenArgs = configArg;
        return {};
      };
      // Mock transloco.translate para cualquier argumento
      (transloco.translate as any) = (...args: any[]) => 'Error inesperado';
      component.nameControl.setValue('Test');
      component.surnameControl.setValue('User');
      component.excelControl.setValue(null);
      component.onSubmit();
      expect(dialogOpenCalled).toBe(true);
      expect(dialogOpenArgs.data.message).toBe('Error inesperado');
    });
  });
});
