import { MatDialog } from '@angular/material/dialog';
import { ErrorMessageDialog } from './components/error-message-dialog/error-message-dialog';
import { Component, signal } from '@angular/core';
import { excelFileValidator } from './validators/excel-file.validator';
import { FormGroup, FormControl, Validators, ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { TranslocoModule } from '@jsverse/transloco';
import { environment } from '../environments/environment';
import { CandidateResponse } from './components/table-candidates/interfaces/candidate-response.interface';
import { TableCandidates } from './components/table-candidates/table-candidates';
// ...existing code...
import { TranslocoService } from '@jsverse/transloco';
import { LanguageSelector } from './components/language-selector/language-selector';
// ...existing code...

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatCardModule,
    TranslocoModule,
    MatProgressSpinnerModule,
    TableCandidates,
    LanguageSelector
  ],
  templateUrl: './app.html',
  styleUrl: './app.scss'
})
export class App {
  
  loading = signal(false);
  candidate = signal<CandidateResponse | undefined>(undefined);
  // Track the file name
  excelFileName: string = '';

  submitEnabled = true;

  // Sinstaxis more readable in the template
  nameControl = new FormControl<string>('', [Validators.required, Validators.minLength(2)]);
  surnameControl = new FormControl<string>('', [Validators.required, Validators.minLength(2)]);
  excelControl = new FormControl<File | null>(null, [excelFileValidator]);
  
  // Create the form group
  form = new FormGroup({
    name: this.nameControl,
    surname: this.surnameControl,
    excel: this.excelControl,
  });

  constructor(private http: HttpClient, private dialog: MatDialog, private transloco: TranslocoService) {}

  onFileChange(event: Event) {
    const input = event.target as HTMLInputElement;
    const excelControl = this.form.get('excel');
    if (input.files && input.files.length > 0) {
      const file = input.files[0];
      excelControl?.setValue(file);
      excelControl?.markAsTouched();
      excelControl?.updateValueAndValidity();
      this.excelFileName = file.name;
      // Invalid file, clean the input file and show error
      const errors = excelControl?.errors;
      if (errors && errors['invalidExtension']) {
        excelControl?.setValue(null);
        excelControl?.markAsTouched();
        excelControl?.updateValueAndValidity();
        input.value = '';
        this.excelFileName = '';
      }
    } else {
      // When the user delete the back file
      excelControl?.setValue(null);
      excelControl?.markAsTouched();
      excelControl?.updateValueAndValidity();
      this.excelFileName = '';
    }
  }

  // Send form data and Excel file to backend
  onSubmit() {
    // Show spinner
    this.loading.set(true);
    // Create FormData object
    const formData = new FormData();
    formData.append('name', this.nameControl.value ?? '');
    formData.append('surname', this.surnameControl.value ?? '');
    // Add Excel file only if it exists
    if (this.excelControl.value) {
      formData.append('excel', this.excelControl.value);
    }
    // Send POST request to backend
    this.http.post<CandidateResponse>(environment.apiUrlCandidates, formData).subscribe({
      next: (response) => {
        // Hide spinner
        this.loading.set(false);
        // Assign received data to the table
        this.candidate.set(response);
        // Reset the form
        this.form.reset();
        this.excelFileName = '';
        // Quitar validadores tras el reset
        this.nameControl.clearValidators();
        this.surnameControl.clearValidators();
        this.excelControl.clearValidators();
        Object.values(this.form.controls).forEach(control => {
          control.setErrors(null);
          control.markAsPristine();
          control.markAsUntouched();
          control.updateValueAndValidity();
        });
        this.submitEnabled = false;
      },
      error: (error) => {
        // Hide spinner and show error message
        this.loading.set(false);
        this.dialog.open(ErrorMessageDialog, {
          data: {
            title: this.transloco.translate('error-message-dialog.title', {}, 'es'),
            message:
              error?.error?.message ||
              error.message ||
              this.transloco.translate('error-message-dialog.default', {}, 'es')
          },
          width: '400px',
          disableClose: false
        });
      }
    });
  }

  restoreNameValidators() {
    this.nameControl.setValidators([Validators.required, Validators.minLength(2)]);
    this.nameControl.updateValueAndValidity();
    this.submitEnabled = true;
  }

  restoreSurnameValidators() {
    this.surnameControl.setValidators([Validators.required, Validators.minLength(2)]);
    this.surnameControl.updateValueAndValidity();
    this.submitEnabled = true;
  }

  restoreExcelValidators() {
    this.excelControl.setValidators([excelFileValidator]);
    this.excelControl.updateValueAndValidity();
    this.submitEnabled = true;
  }
}
