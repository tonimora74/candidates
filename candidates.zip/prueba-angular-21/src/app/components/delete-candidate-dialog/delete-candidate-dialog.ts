import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { CandidateResponse } from '../table-candidates/interfaces/candidate-response.interface';
import { TranslocoModule } from '@jsverse/transloco';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'delete-candidate-dialog',
  standalone: true,
  templateUrl: './delete-candidate-dialog.html',
  styleUrls: ['./delete-candidate-dialog.scss'],
  imports: [TranslocoModule, MatDialogModule, MatIconModule]
})
export class DeleteCandidateDialog {
  constructor(
    @Inject(MAT_DIALOG_DATA) public data: CandidateResponse,
    private dialogRef: MatDialogRef<DeleteCandidateDialog>
  ) {}

  // Closes the dialog when the close icon is clicked
  closeDialog() {
    this.dialogRef.close();
    // Clear data after closing to avoid showing stale info if reused
    this.data = {} as CandidateResponse;
  }
}
