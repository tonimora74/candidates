import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { TranslocoModule } from '@jsverse/transloco';
import { MatIconModule } from '@angular/material/icon';

export interface ErrorMessageData {
  title: string;
  message: string;
}

@Component({
  selector: 'error-message-dialog',
  standalone: true,
  templateUrl: './error-message-dialog.html',
  styleUrls: ['./error-message-dialog.scss'],
  imports: [TranslocoModule, MatDialogModule, MatIconModule]
})
export class ErrorMessageDialog {
  title: string;
  message: string;

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: ErrorMessageData,
    private dialogRef: MatDialogRef<ErrorMessageDialog>
  ) {
    this.title = data.title;
    this.message = data.message;
  }

  closeDialog() {
    this.dialogRef.close();
  }
}
