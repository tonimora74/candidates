import { Component } from '@angular/core';
import { TranslocoModule, TranslocoService } from '@jsverse/transloco';
import { MatSelectModule } from '@angular/material/select';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'language-selector',
  standalone: true,
  imports: [CommonModule, MatSelectModule, TranslocoModule,],
  template: `
    <mat-form-field appearance="outline" style="width: 130px; margin-top: 18px;">
      <mat-label>{{ 'language-selector.Language' | transloco }}</mat-label>
      <mat-select [value]="activeLang" (selectionChange)="changeLang($event.value)">
        <mat-option *ngFor="let lang of langs" [value]="lang">
          {{ 'language-selector.langNames.' + lang | transloco }}
        </mat-option>
      </mat-select>
    </mat-form-field>
  `,
})
export class LanguageSelector {
  langs: string[];
  activeLang: string;

  constructor(private translocoService: TranslocoService) {
    this.langs = this.translocoService.getAvailableLangs() as string[];
    this.activeLang = this.translocoService.getActiveLang();
  }

  changeLang(lang: string) {
    this.translocoService.setActiveLang(lang);
    this.activeLang = lang;
  }
}
