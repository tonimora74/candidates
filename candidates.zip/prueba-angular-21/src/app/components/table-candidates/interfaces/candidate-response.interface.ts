export interface CandidateResponse {
  name: string;
  surname: string;
  seniority: string;
  years: number;
  availability: boolean;
}
