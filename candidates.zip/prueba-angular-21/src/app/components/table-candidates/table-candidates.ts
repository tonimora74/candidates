import { Component, computed, Input, signal } from '@angular/core';
import { CandidateResponse } from './interfaces/candidate-response.interface';
import { CommonModule } from '@angular/common';
import { MatTableModule } from '@angular/material/table';
import { TranslocoModule } from '@jsverse/transloco';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatDialog } from '@angular/material/dialog';
import { DeleteCandidateDialog } from '../delete-candidate-dialog/delete-candidate-dialog';

@Component({
  selector: 'table-candidates',
  standalone: true,
  imports: [CommonModule, MatTableModule, MatCardModule, TranslocoModule, MatIconModule],
  templateUrl: './table-candidates.html',
  styleUrls: ['./table-candidates.scss']
})
export class TableCandidates {

  candidates = signal<CandidateResponse[]>([]);
  
  constructor(private dialog: MatDialog) {}

  @Input()
  set candidate(value: CandidateResponse | undefined) {
    if (value) {
      this.candidates.set([...this.candidates(), value]);
    }
  }

  displayedColumns: string[] = ['name', 'surname', 'seniority', 'years', 'availability', 'actions'];

  removeCandidate(index: number) {
    // Create a copy of the candidates array
    const arr = [...this.candidates()];
    // Get the candidate to be deleted by index
    const deleted = arr[index];
    // Remove the candidate from the array
    arr.splice(index, 1);
    // Update the candidates signal with the new array
    this.candidates.set(arr);
    // Open the DeleteCandidateDialog modal, passing the deleted candidate's data
    this.dialog.open(DeleteCandidateDialog, {
      data: deleted,
      width: '350px',
      disableClose: true
    });
  }
}
