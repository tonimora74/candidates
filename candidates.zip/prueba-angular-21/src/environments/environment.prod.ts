export const environment = {
  production: true,
  apiUrlCandidates: 'https://api.tu-dominio.com/candidates',
  transloco: {
    availableLangs: ['en', 'es'],
    defaultLang: 'es'
  }
};
