import { Test, TestingModule } from '@nestjs/testing';
import { CandidatesController } from './candidates.controller';
import { CandidatesExcelService } from './services/candidates-excel.service';
import { CreateCandidateDto } from './dto/create-candidate.dto';

describe('CandidatesController', () => {
  let candidatesController: CandidatesController;
  let candidatesExcelService: CandidatesExcelService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [CandidatesController],
      providers: [CandidatesExcelService],
    }).compile();

    candidatesController =
      module.get<CandidatesController>(CandidatesController);
    candidatesExcelService = module.get<CandidatesExcelService>(
      CandidatesExcelService,
    );
  });

  it('should be defined', () => {
    expect.assertions(1);

    expect(candidatesController).toBeDefined();
  });

  it('should process candidate and return response', () => {
    expect.assertions(1);

    const body: CreateCandidateDto = { name: 'John', surname: 'Doe' };
    const file: any = { buffer: Buffer.alloc(0) };
    jest.spyOn(candidatesExcelService, 'processCandidate').mockReturnValue({
      seniority: 'junior',
      years: 2,
      availability: true,
    });
    const result = candidatesController.createCandidate(body, file);
    expect(result).toEqual({
      name: 'John',
      surname: 'Doe',
      seniority: 'junior',
      years: 2,
      availability: true,
    });
  });
});
