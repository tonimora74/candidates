import {
  Controller,
  Post,
  Body,
  UploadedFile,
  UseInterceptors,
  UsePipes,
  ValidationPipe,
  Get,
  Res,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import type { Express, Response } from 'express';

// Aplication imports
import { CreateCandidateDto } from './dto/create-candidate.dto';
import { CandidatesExcelService } from './services/candidates-excel.service';
import type { CandidateResponse } from './interfaces/candidate-response.interface';
import { ExcelValidationPipe } from './pipes/excel-validation.pipe';
import { join } from 'path';

@Controller('candidates')
export class CandidatesController {
  constructor(
    private readonly candidatesExcelService: CandidatesExcelService,
  ) {}

  @Post()
  @UseInterceptors(FileInterceptor('excel'))
  @UsePipes(new ValidationPipe({ whitelist: true }))
  createCandidate(
    @Body() body: CreateCandidateDto,
    @UploadedFile(new ExcelValidationPipe()) file: Express.Multer.File,
  ): CandidateResponse {
    // Get data from excel file
    const excelData = this.candidatesExcelService.processCandidate(file.buffer);
    // Return combined data
    return {
      name: body.name,
      surname: body.surname,
      seniority: excelData.seniority,
      years: excelData.years,
      availability: excelData.availability,
    };
  }

  @Get('example-excel')
  downloadExcel(@Res() res: Response) {
    const filePath = join(process.cwd(), 'files', 'candidates.xlsx');
    res.download(filePath, 'candidates_template.xlsx');
  }
}
