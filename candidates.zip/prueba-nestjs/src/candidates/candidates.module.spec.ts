import { Test, TestingModule } from '@nestjs/testing';
import { CandidatesModule } from './candidates.module';
import { CandidatesController } from './candidates.controller';
import { CandidatesExcelService } from './services/candidates-excel.service';

// Basic configuration test for CandidatesModule

describe('CandidatesModule', () => {
  let module: TestingModule;

  beforeAll(async () => {
    module = await Test.createTestingModule({
      imports: [CandidatesModule],
    }).compile();
  });

  it('should define CandidatesController', () => {
    const controller = module.get<CandidatesController>(CandidatesController);
    expect(controller).toBeDefined();
  });

  it('should define CandidatesExcelService', () => {
    const service = module.get<CandidatesExcelService>(CandidatesExcelService);
    expect(service).toBeDefined();
  });
});
