import { Seniority } from './candidate-request.interface';

export interface CandidateResponse {
  name: string;
  surname: string;
  seniority: Seniority;
  years: number;
  availability: boolean;
}
