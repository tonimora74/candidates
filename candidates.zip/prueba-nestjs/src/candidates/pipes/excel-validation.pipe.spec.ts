import { ExcelValidationPipe } from './excel-validation.pipe';
import * as XLSX from 'xlsx';
import { BadRequestException } from '@nestjs/common';

describe('ExcelValidationPipe', () => {
  let excelValidationPipe: ExcelValidationPipe;

  beforeEach(() => {
    excelValidationPipe = new ExcelValidationPipe();
  });

  it('should pass with valid excel file', () => {
    expect.assertions(1);
    // Create a mock Excel buffer with 3 headers and 3 values
    const data: [string, string, string][] = [
      ['Seniority', 'Years of experience', 'Availability'],
      ['junior', '2', 'true'],
    ];
    const ws = XLSX.utils.aoa_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
    // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
    const buffer: Buffer = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
    const file = {
      buffer,
      size: buffer.length,
      mimetype:
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    } as Express.Multer.File;

    const excelValidationPipeResponse = excelValidationPipe.transform(file);

    expect(excelValidationPipeResponse).toBe(file);
  });

  it('should throw if file is missing', () => {
    expect.assertions(3);

    try {
      excelValidationPipe.transform(undefined as any);
    } catch (error) {
      expect(error).toBeInstanceOf(BadRequestException);
      // eslint-disable-next-line @typescript-eslint/no-unsafe-member-access
      expect(error.message).toBe(
        'Excel file is required. You can download a valid example Excel at /candidates/example-excel.'
      );
      expect((error as BadRequestException).getStatus()).toBe(400);
    }
  });

  it('should throw if mimetype is incorrect', () => {
    expect.assertions(3);
    // Create a mock Excel buffer
    const file = {
      buffer: Buffer.alloc(10),
      size: 10,
      mimetype: 'text/plain',
    } as Express.Multer.File;
    try {
      excelValidationPipe.transform(file);
    } catch (error: any) {
      expect(error).toBeInstanceOf(BadRequestException);
      expect((error as BadRequestException).message).toBe(
        'File must be an .xlsx Excel file. You can download a valid example Excel at /candidates/example-excel.',
      );
      expect((error as BadRequestException).getStatus()).toBe(400);
    }
  });

  it('should throw if file is empty', () => {
    expect.assertions(3);
    // Create a mock empty Excel buffer
    const file = {
      buffer: Buffer.alloc(0),
      size: 0,
      mimetype:
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    } as Express.Multer.File;

    try {
      excelValidationPipe.transform(file);
    } catch (error: any) {
      expect(error).toBeInstanceOf(BadRequestException);
      expect((error as BadRequestException).message).toBe(
        'Excel file is empty. You can download a valid example Excel at /candidates/example-excel.',
      );
      expect((error as BadRequestException).getStatus()).toBe(400);
    }
  });

  it('should throw if headers are missing', () => {
    expect.assertions(3);
    // Create a mock Excel buffer with missing headers
    const data: [string, string][] = [
      ['Seniority', 'Years of experience'],
      ['junior', '2'],
    ];
    const ws = XLSX.utils.aoa_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
    // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
    const buffer: Buffer = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });

    const file = {
      buffer,
      size: buffer.length,
      mimetype:
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    } as Express.Multer.File;

    try {
      excelValidationPipe.transform(file);
    } catch (error: any) {
      expect(error).toBeInstanceOf(BadRequestException);
      expect((error as BadRequestException).message).toBe(
        'Excel file must have exactly 3 headers. You can download a valid example Excel at /candidates/example-excel.',
      );
      expect((error as BadRequestException).getStatus()).toBe(400);
    }
  });

  it('should throw if values are missing', () => {
    expect.assertions(3);
    // Create a mock Excel buffer with missing values
    const data: [string, string, string][] = [
      ['Seniority', 'Years of experience', 'Availability'],
      ['junior', '', 'true'],
    ];
    const ws = XLSX.utils.aoa_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
    // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
    const buffer: Buffer = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });

    const file = {
      buffer,
      size: buffer.length,
      mimetype:
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    } as Express.Multer.File;

    try {
      excelValidationPipe.transform(file);
    } catch (error: any) {
      expect(error).toBeInstanceOf(BadRequestException);
      expect((error as BadRequestException).message).toBe(
        'Excel file value at position 2 is empty or invalid. You can download a valid example Excel at /candidates/example-excel.',
      );
      expect((error as BadRequestException).getStatus()).toBe(400);
    }
  });
});
