import { CandidatesExcelService } from './candidates-excel.service';
import * as XLSX from 'xlsx';

describe('CandidatesExcelService', () => {
  let service: CandidatesExcelService;

  beforeEach(() => {
    service = new CandidatesExcelService();
  });

  it('should be defined', () => {
    expect.assertions(1);

    expect(service).toBeDefined();
  });

  it('should process valid excel buffer and return correct response', () => {
    expect.assertions(1);

    // Create a mock Excel buffer with 3 headers and 3 values
    const data: [string, string, string][] = [
      ['Seniority', 'Years of experience', 'Availability'],
      ['junior', '2', 'true'],
    ];
    const ws = XLSX.utils.aoa_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
    // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
    const excelBuffer: Buffer = XLSX.write(wb, {
      type: 'buffer',
      bookType: 'xlsx',
    });

    const result = service.processCandidate(excelBuffer);

    expect(result).toEqual({
      seniority: 'junior',
      years: 2,
      availability: true,
    });
  });

  it('should handle false availability', () => {
    expect.assertions(1);
    // Create a mock Excel buffer with 3 headers and 3 values
    const data: [string, string, string][] = [
      ['Seniority', 'Years of experience', 'Availability'],
      ['senior', '5', 'false'],
    ];
    const ws = XLSX.utils.aoa_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
    // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
    const excelBuffer: Buffer = XLSX.write(wb, {
      type: 'buffer',
      bookType: 'xlsx',
    });

    const result = service.processCandidate(excelBuffer);
    expect(result).toEqual({
      seniority: 'senior',
      years: 5,
      availability: false,
    });
  });

  it('should handle senior seniority', () => {
    expect.assertions(1);

    // Create a mock Excel buffer with senior seniority
    const data: [string, string, string][] = [
      ['Seniority', 'Years of experience', 'Availability'],
      ['senior', '10', 'true'],
    ];
    const ws = XLSX.utils.aoa_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
    // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
    const excelBuffer: Buffer = XLSX.write(wb, {
      type: 'buffer',
      bookType: 'xlsx',
    });

    const result = service.processCandidate(excelBuffer);
    expect(result).toEqual({
      seniority: 'senior',
      years: 10,
      availability: true,
    });
  });
});
