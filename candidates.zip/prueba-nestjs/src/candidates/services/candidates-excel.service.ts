import { Injectable } from '@nestjs/common';
import * as XLSX from 'xlsx';
import { Seniority } from '../interfaces/candidate-request.interface';
import { CandidatesExcelServiceResponse } from '../interfaces/candidates-excel-service.interface';

@Injectable()
export class CandidatesExcelService {
  processCandidate(excelData: Buffer): CandidatesExcelServiceResponse {
    // Reed the Excel from buffer
    const workbook = XLSX.read(excelData, { type: 'buffer' });
    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];
    // Convert sheet to JSON
    const rows = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
    // get headers and values
    const [rawHeaders, rawValues] = rows;
    const headers = rawHeaders as string[];
    const values = rawValues as (string | number)[];
    // Find the indexes of the fields
    const seniorityIdx = headers.indexOf('Seniority');
    const yearsIdx = headers.indexOf('Years of experience');
    const availabilityIdx = headers.indexOf('Availability');
    // Extract values
    const seniority = values[seniorityIdx] as Seniority;
    const years = Number(values[yearsIdx]);
    const availability = values[availabilityIdx] === 'true';

    return {
      seniority,
      years,
      availability,
    };
  }
}
