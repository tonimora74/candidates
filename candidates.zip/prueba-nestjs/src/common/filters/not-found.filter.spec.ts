/* eslint-disable @typescript-eslint/no-unsafe-member-access */
import { NotFoundFilter } from './not-found.filter';
import { ArgumentsHost, NotFoundException } from '@nestjs/common';

describe('NotFoundFilter', () => {
  it('should return a 404 response with the correct structure', () => {
    expect.assertions(6);
    // Mocking the ArgumentsHost and response methods
    const mockJson = jest.fn();
    const mockStatus = jest.fn(() => ({ json: mockJson }));
    const mockGetResponse = jest.fn(() => ({ status: mockStatus }));
    const mockSwitchToHttp = jest.fn(() => ({ getResponse: mockGetResponse }));
    const mockHost = {
      switchToHttp: mockSwitchToHttp,
    } as unknown as ArgumentsHost;
    // Creating an instance of the filter and invoking the catch method
    const exception = new NotFoundException();
    const filter = new NotFoundFilter();
    filter.catch(exception, mockHost);

    expect(mockStatus).toHaveBeenCalledWith(404);
    expect(mockJson).toHaveBeenCalled();

    // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
    const responseObj = mockJson.mock.calls[0][0];
    expect(responseObj.statusCode).toBe(404);
    expect(responseObj.message).toBe('Route not found');
    expect(responseObj.error).toBe('Not Found');
    expect(typeof responseObj.timestamp).toBe('string');
  });
});
