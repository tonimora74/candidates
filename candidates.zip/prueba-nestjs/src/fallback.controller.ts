import { Controller, All, Req, Res } from '@nestjs/common';
import type { Request, Response } from 'express';

@Controller()
export class FallbackController {
  @All('*')
  handleAll(@Req() req: Request, @Res() res: Response) {
    res.status(404).json({
      statusCode: 404,
      message: 'Route not found',
      error: 'Not Found',
      timestamp: new Date().toISOString(),
    });
  }
}
