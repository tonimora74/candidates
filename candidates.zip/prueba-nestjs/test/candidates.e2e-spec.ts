/* eslint-disable @typescript-eslint/no-unsafe-member-access */
import { Test, TestingModule } from '@nestjs/testing';
import { INestApplication } from '@nestjs/common';
import request from 'supertest';
import { App } from 'supertest/types';
import * as XLSX from 'xlsx';
import { AppModule } from './../src/app.module';

describe('/candidates (POST) e2e', () => {
  let app: INestApplication<App>;

  beforeEach(async () => {
    const moduleFixture: TestingModule = await Test.createTestingModule({
      imports: [AppModule],
    }).compile();

    app = moduleFixture.createNestApplication();
    await app.init();
  });

  it('/candidates (POST) - should validate and accept correct data', async () => {
    expect.assertions(6);

    // Create a mock Excel buffer with 3 headers and 3 values
    const excelData = [
      ['Seniority', 'Years of experience', 'Availability'],
      ['junior', '2', 'true'],
    ];
    const ws = XLSX.utils.aoa_to_sheet(excelData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
    const buffer: Buffer = XLSX.write(wb, {
      type: 'buffer',
      bookType: 'xlsx',
    }) as Buffer;

    const response = await request(app.getHttpServer())
      .post('/candidates')
      .field('name', 'John')
      .field('surname', 'Doe')
      .attach('excel', buffer, {
        filename: 'test.xlsx',
        contentType:
          'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      });

    expect(response.status).toBe(201);
    expect(response.body).toHaveProperty('name', 'John');
    expect(response.body).toHaveProperty('surname', 'Doe');
    expect(response.body).toHaveProperty('seniority', 'junior');
    expect(response.body).toHaveProperty('years', 2);
    expect(response.body).toHaveProperty('availability', true);
  });

  it('/candidates (POST) - should fail if surname is missing', async () => {
    expect.assertions(2);

    // Create a mock Excel buffer with 3 headers and 3 values
    const excelData = [
      ['Seniority', 'Years of experience', 'Availability'],
      ['junior', '2', 'true'],
    ];
    const ws = XLSX.utils.aoa_to_sheet(excelData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
    const buffer: Buffer = XLSX.write(wb, {
      type: 'buffer',
      bookType: 'xlsx',
    }) as Buffer;

    const response = await request(app.getHttpServer())
      .post('/candidates')
      .field('name', 'John')
      // .field('surname', 'Doe') // Surname intentionally omitted
      .attach('excel', buffer, {
        filename: 'test.xlsx',
        contentType:
          'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      });

    expect(response.status).toBe(400);
    // ["surname should not be empty", "surname must be a string"]
    expect(
      // eslint-disable-next-line @typescript-eslint/no-unsafe-call
      response.body.message.some((msg: string) => msg.includes('surname')),
    ).toBe(true);
  });
});
